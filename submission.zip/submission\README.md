# AI Stock Research & SEC Filing RAG Assistant

## Prerequisites
- Python >= 3.10
- uv (for rag_agent)
- Docker Desktop (for Qdrant Vector DB)

## How to Run
1. Start Qdrant: docker run -p 6333:6333 qdrant/qdrant
2. Copy .env.example to .env in both stock_agent and rag_agent, and set GOOGLE_API_KEY.
3. Run RAG agent (port 8000): cd rag_agent && uv sync && uv run uvicorn main:app --reload --port 8000
4. Run Stock agent (port 8001): cd stock_agent && pip install -r requirements.txt && uvicorn main:app --reload --port 8001
5. Open stock_agent/index.html in browser.
